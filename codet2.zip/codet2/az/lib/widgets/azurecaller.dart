import 'package:flutter/material.dart';
import 'package:musicapp_wend/db/azureauth.dart';

class AzureCaller extends StatefulWidget {
  @override
  _AzureCallerState createState() => _AzureCallerState();
}

class _AzureCallerState extends State<AzureCaller> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(),
      body: Column(
        children: [
          RaisedButton(
            onPressed: () {
              AzureAuthOperations opr = AzureAuthOperations();
              opr.login();
            },
            child: Text('Login'),
          )
        ],
      ),
    );
  }
}
