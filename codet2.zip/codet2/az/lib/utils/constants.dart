class Constants {
  static final String SINGER_URL =
      "https://raw.githubusercontent.com/brainmentorspvtltd/myserverdata/master/singers.json";
  static final String LEFT_BORDER_IMAGE =
      "https://raw.githubusercontent.com/brainmentorspvtltd/myserverdata/master/leftborder.png";
  static final String RIGHT_BORDER_IMAGE =
      "https://webstockreview.net/images/clipart-banner-corner-9.png";
  static final String LOGIN_GMAIL =
      "https://cdn.iconscout.com/icon/free/png-256/google-2981831-2476479.png";
}
