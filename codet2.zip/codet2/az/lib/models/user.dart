class User {
  String _emailId;
  String _phone;
  String _photo;
  String _name;

  User(this._emailId, this._phone, this._photo, this._name);

  String get name => _name;

  set name(String value) {
    _name = value;
  }

  String get photo => _photo;

  set photo(String value) {
    _photo = value;
  }

  String get phone => _phone;

  set phone(String value) {
    _phone = value;
  }

  String get emailId => _emailId;

  set emailId(String value) {
    _emailId = value;
  }
}
