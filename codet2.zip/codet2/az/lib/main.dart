import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:musicapp_wend/screens/artist.dart';

import 'models/user.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  Firebase.initializeApp();
  runApp(MaterialApp(
      title: 'Music App',
      //   home: Login()
      home: ArtistScreen(User(
          'amit@gmail.com',
          '2222',
          'https://pbs.twimg.com/profile_images/729762910562484225/uYPbK_R1_400x400.jpg',
          'Amit'))));
}
