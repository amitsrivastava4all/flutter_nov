import 'dart:convert' as convert;

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class ApiCall extends StatefulWidget {
  @override
  _ApiCallState createState() => _ApiCallState();
}

class _ApiCallState extends State<ApiCall> {
  String URL =
      "https://api.giphy.com/v1/gifs/search?api_key=vFRSFWo6g7vJ7ZAjt3DMDolU52ORTxwH&q=Iron%20Man&limit=5";
  List<dynamic> images = [];
  initState() {
    super.initState();
    callServer();
  }

  responseToObject(http.Response response) {
    Map<String, dynamic> map = convert.jsonDecode(response.body);
    List<dynamic> list = map['data'];
    return list;
    //['images']['original']['url'];
  }

  callServer({searchValue = "Iron Man"}) {
    URL =
        "https://api.giphy.com/v1/gifs/search?api_key=vFRSFWo6g7vJ7ZAjt3DMDolU52ORTxwH&q=$searchValue&limit=5";
    Future<http.Response> future = http.get(URL);

    future
        .then((http.Response response) => setState(() {
              images = responseToObject(response);
            }))
        // print('Response ${response.body.runtimeType} ${response.body}'))
        .catchError((err) => print(err));
  }

  TextEditingController tc = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Search App'),
        backgroundColor: Colors.blue,
        bottom: PreferredSize(
            preferredSize: Size.fromHeight(100),
            child: Container(
              padding: EdgeInsets.only(left: 20),
              //color: Colors.white,
              decoration: BoxDecoration(
                  color: Colors.white, borderRadius: BorderRadius.circular(20)),
              child: TextField(
                controller: tc,
                decoration: InputDecoration(
                  labelText: 'Type to Search',
                  labelStyle: TextStyle(
                    fontSize: 32,
                  ),
                  suffixIcon: IconButton(
                    onPressed: () {
                      callServer(searchValue: tc.text);
                    },
                    icon: Icon(Icons.search),
                  ),
                  // border: OutlineInputBorder()
                ),
              ),
            )),
      ),
      body: Container(
        child: ListView.builder(
          itemCount: images.length,
          itemBuilder: (BuildContext b, int index) {
            return Card(
              child: Image.network(images[index]['images']['original']['url']),
            );
          },
        ),
      ),
    );
  }
}
