import 'dart:convert';

import 'package:flutter_firebase_crud/models/dropdownmodel.dart';
import 'package:http/http.dart' as http;

class ServerCall {
  static Future<List<DropDownModel>> getDropDownValues() async {
    http.Response response = await http.get(
        'https://raw.githubusercontent.com/amitsrivastava4all/flutter_nov/main/stores.json');
    print("Response Body ");
    //print(response.body);
    var map = jsonDecode(response.body);
    print("Type is ");
    print(map["x"].runtimeType);

    List<dynamic> jsonList = jsonDecode(map["x"]);
    List<DropDownModel> list = [];
    list = jsonList.map((dynamic obj) {
      DropDownModel dropDownModel = new DropDownModel();
      dropDownModel.value = obj["StoreID"].toString();
      dropDownModel.displayValue = obj["LSTDESC"];
      return dropDownModel;
    }).toList();

    // dropDownModel = new DropDownModel();
    // dropDownModel.value = "US";
    // dropDownModel.displayValue = "United States";
    // list.add(dropDownModel);
    print("List is ");
    print(list);
    return list;
  }
}
