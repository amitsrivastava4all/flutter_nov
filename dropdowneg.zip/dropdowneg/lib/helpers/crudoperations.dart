import 'package:cloud_firestore/cloud_firestore.dart';

class CrudOperations {
  static CrudOperations _crudOperations;
  FirebaseFirestore dbReference;
  CollectionReference collectionReference;
  CrudOperations.init() {
    dbReference = FirebaseFirestore.instance;
    collectionReference = dbReference.collection('notes');
  }

  static CrudOperations getInstance() {
    if (_crudOperations == null) {
      _crudOperations = CrudOperations.init();
    }
    return _crudOperations;
  }

  Future<String> addNewNote(Map<String, dynamic> map) async {
    DocumentReference documentReference;
    try {
      documentReference = await collectionReference.add(map);
      return documentReference.id;
    } catch (e) {
      return null;
    }
  }

  removeNote() {}
  findNote() {}
  Future<List<QueryDocumentSnapshot>> readAllNotes() async {
    CollectionReference collectionReference = dbReference.collection('notes');
    QuerySnapshot querySnapshot = await collectionReference.get();

    return querySnapshot.docs;
  }
}
