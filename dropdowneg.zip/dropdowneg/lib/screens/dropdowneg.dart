import 'package:flutter/material.dart';
import 'package:flutter_firebase_crud/helpers/servercall.dart';
import 'package:flutter_firebase_crud/models/dropdownmodel.dart';

class DropDownExample extends StatefulWidget {
  @override
  _DropDownExampleState createState() => _DropDownExampleState();
}

class _DropDownExampleState extends State<DropDownExample> {
  String _selectedLocation;
  @override
  Widget build(BuildContext context) {
    ServerCall.getDropDownValues();
    return Scaffold(
      appBar: AppBar(),
      body: Column(
        children: [
          Text(
            'Drop Down Example',
            style: TextStyle(fontSize: 32),
          ),
          FutureBuilder<List<DropDownModel>>(
            builder:
                (BuildContext bt, AsyncSnapshot<List<DropDownModel>> snapshot) {
              if (!snapshot.hasData) {
                return CircularProgressIndicator();
              }
              if (snapshot.hasError) {
                return Text('No Data Found !');
              }
              return DropdownButton<String>(
                hint: Text('Please choose a location'),
                value: _selectedLocation,
                onChanged: (newValue) {
                  _selectedLocation = newValue;
                  setState(() {});
                },
                items: snapshot.data.map((DropDownModel item) {
                  return new DropdownMenuItem<String>(
                      child: Text(item.displayValue), value: item.value);
                }).toList(),
              );
            },
            future: ServerCall.getDropDownValues(),
          )
        ],
      ),
    );
  }
}
