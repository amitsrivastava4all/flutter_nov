class DropDownModel {
  String _value;
  String _displayValue;

  String get value => _value;

  set value(String value) {
    _value = value;
  }

  String get displayValue => _displayValue;

  set displayValue(String value) {
    _displayValue = value;
  }

  @override
  String toString() {
    return 'DropDownModel{_value: $_value, _displayValue: $_displayValue}';
  }
}
