import 'dart:convert' as convert;

import 'package:http/http.dart' as http;
import 'package:musicapp_wend/models/singer.dart';

class ServerCall {
  static Future<http.Response> callServer(String url) {
    return http.get(url);
  }

  static Future<List<Singer>> convertResponseIntoSinger(String url) async {
    http.Response response = await callServer(url);
    String json = response.body;
    dynamic map = convert.jsonDecode(json);
    //print('Singers $map');
    List<dynamic> singerList = map['singers'];
    // print("Before Convert $singerList");
    // List<Singer> singers =
    //     singerList.map((singer) => Singer(singer['name'], singer['photo']));
    // List<Singer> singers = [];
    /*
    for (Map<String, dynamic> singer in singerList) {
      print("Singer ${singer['photo']}");
      Singer s = new Singer(singer['name'], singer['photo']);
      // print(s);
      singers.add(s);
      //Singer s = Singer(singer['name'], singer['photo']);
      //print("Singer $s");
      //singers.add(s);
    }
    print("After Convert singers $singers");
    */
    List<Singer> singers = singerList
        .map((singer) => Singer(singer['name'], singer['photo']))
        .toList();
    return singers;
  }
}
