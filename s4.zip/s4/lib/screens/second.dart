import 'package:flutter/material.dart';

class AlignDemo extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Container(
          width: 200,
          height: 200,
          color: Colors.redAccent,
          child: Align(
            child: Text('Hello'),
            // alignment: Alignment(0.4, 0),
            alignment: Alignment.topRight,
          ),
        ),
      ),
    );
  }
}
