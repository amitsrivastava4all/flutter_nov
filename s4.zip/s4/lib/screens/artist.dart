import 'package:flutter/material.dart';
import 'package:musicapp_wend/models/singer.dart';
import 'package:musicapp_wend/models/user.dart';
import 'package:musicapp_wend/utils/constants.dart';
import 'package:musicapp_wend/utils/servercall.dart';

class ArtistScreen extends StatefulWidget {
  User user;
  ArtistScreen(User user) {
    this.user = user;
  }
  @override
  _ArtistScreenState createState() => _ArtistScreenState();
}

class _ArtistScreenState extends State<ArtistScreen> {
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
  }

  Widget _error() {
    return Center(
      child: Text(
        'Error in Singer Data',
        style: TextStyle(fontSize: 30),
      ),
    );
  }

  Widget _loading() {
    return Center(
      child: CircularProgressIndicator(),
    );
  }

  Widget _getList(AsyncSnapshot snapshot) {
    return ListView.builder(
      itemCount: snapshot.data.length,
      itemBuilder: (BuildContext b, int index) {
        print('Future ${snapshot.data[index].runtimeType}');
        Singer singer = snapshot.data[index];
        return ListTile(
          leading: Image.network(singer.photo),
          title: Text(singer.name),
        );
      },
    );
  }

  Widget _gridContent(Singer singer) {
    return Column(
      children: [
        Container(
          margin: EdgeInsets.all(5),
          child: CircleAvatar(
            maxRadius: 50,
            backgroundImage: NetworkImage(singer.photo),
          ),
        ),
        Text(singer.name)
      ],
    );
  }

  Widget _getGrid(AsyncSnapshot snapshot) {
    return GridView.builder(
      itemCount: snapshot.data.length,
      gridDelegate:
          SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2),
      itemBuilder: (BuildContext b, int index) {
        print('Future ${snapshot.data[index].runtimeType}');
        Singer singer = snapshot.data[index];
        return _gridContent(singer);
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Artist'),
      ),
      drawer: Drawer(
        child: Column(
          children: [
            UserAccountsDrawerHeader(
                currentAccountPicture: CircleAvatar(
                  backgroundImage: NetworkImage(widget.user.photo),
                ),
                accountName: Text(widget.user.name),
                accountEmail: Text(widget.user.emailId))
          ],
        ),
      ),
      body: Container(
        child: FutureBuilder(
          future: ServerCall.convertResponseIntoSinger(Constants.SINGER_URL),
          builder: (BuildContext bt, AsyncSnapshot snapshot) {
            if (snapshot.hasError) {
              return _error();
            }
            if (!snapshot.hasData) {
              return _loading();
            }
            return _getGrid(snapshot);
          },
        ),
        decoration: BoxDecoration(
            gradient: LinearGradient(colors: [
          Colors.redAccent,
          Colors.purpleAccent,
          Colors.yellowAccent,
          Colors.greenAccent
        ], begin: Alignment.topLeft, end: Alignment.bottomRight)),
      ),
    );
  }
}
