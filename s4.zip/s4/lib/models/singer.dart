class Singer {
  String name;
  String photo;
  Singer(this.name, this.photo);

  @override
  String toString() {
    return 'Singer{_name: $name, _photo: $photo}';
  }
}
