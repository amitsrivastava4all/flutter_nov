class Note {
  String name;
  String desc;
  bool isActive;
  String authorName;
}
