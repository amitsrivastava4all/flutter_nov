import 'package:flutter/material.dart';
import 'package:flutter_firebase_crud/helpers/crudoperations.dart';
import 'package:flutter_firebase_crud/screens/widgets/customtextfield.dart';

class AddScreen extends StatefulWidget {
  @override
  _AddScreenState createState() => _AddScreenState();
}

class _AddScreenState extends State<AddScreen> {
  Map<String, dynamic> map = {};
  void takeValue(String key, dynamic value) {
    map[key] = value;
  }

  String msg = "";
  CrudOperations crudOperations = CrudOperations.getInstance();
  void addANewNote() {
    var result = crudOperations.addNewNote(map);
    if (result != null) {
      msg = "Record Added in FireBase";
    } else {
      msg = "Not Added in FireBase ";
    }
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Add a New Note'),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Text(
              msg,
              style: TextStyle(fontSize: 32),
            ),
            CustomTextField('Name', takeValue),
            CustomTextField('Desc', takeValue),
            CustomTextField('Author', takeValue),
            RaisedButton(
              color: Colors.green,
              onPressed: () {
                addANewNote();
              },
              child: Text(
                'Add',
                style: TextStyle(fontSize: 24),
              ),
            )
          ],
        ),
      ),
    );
  }
}
