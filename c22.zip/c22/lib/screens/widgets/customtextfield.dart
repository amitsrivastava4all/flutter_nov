import 'package:flutter/material.dart';

class CustomTextField extends StatelessWidget {
  String name;
  Function fn;
  CustomTextField(this.name, this.fn) {}
  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.all(10),
      child: TextField(
        onChanged: (String str) {
          this.fn(this.name.toLowerCase(), str);
        },
        decoration: InputDecoration(
            border: OutlineInputBorder(),
            labelText: 'Type Your ${this.name}',
            hintText: 'Type Your ${this.name}'),
      ),
    );
  }
}
