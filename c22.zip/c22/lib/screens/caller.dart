import 'dart:convert' as convert;

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class Caller extends StatefulWidget {
  @override
  _CallerState createState() => _CallerState();
}

class _CallerState extends State<Caller> {
  String msg = "";
  fetchData() async {
    http.Response response = await http.get(
        'https://raw.githubusercontent.com/amitsrivastava4all/flutter_nov/main/email.json');
    Map<String, dynamic> map = convert.jsonDecode(response.body);
    setState(() {
      msg = "Email is " + map["email"] + "password " + map["password"];
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            RaisedButton(
              onPressed: () {
                fetchData();
              },
              child: Text('Fetch'),
            ),
            Text(
              msg,
              style: TextStyle(fontSize: 32),
            )
          ],
        ),
      ),
    );
  }
}
