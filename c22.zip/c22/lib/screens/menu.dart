import 'package:flutter/material.dart';
import 'package:flutter_firebase_crud/screens/caller.dart';

import 'add.dart';
import 'listofnotes.dart';

class MenuApp extends StatefulWidget {
  @override
  _MenuAppState createState() => _MenuAppState();
}

class _MenuAppState extends State<MenuApp> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(),
      body: Column(
        children: [
          RaisedButton(
            onPressed: () {
              Navigator.of(context)
                  .push(MaterialPageRoute(builder: (ctx) => AddScreen()));
            },
            child: Text('Add Note'),
          ),
          RaisedButton(
            onPressed: () {
              Navigator.of(context)
                  .push(MaterialPageRoute(builder: (ctx) => ListofNotes()));
            },
            child: Text('List of Notes'),
          ),
          RaisedButton(
            onPressed: () {
              Navigator.of(context)
                  .push(MaterialPageRoute(builder: (ctx) => Caller()));
            },
            child: Text('API CALL'),
          )
        ],
      ),
    );
  }
}
