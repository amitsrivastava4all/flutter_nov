import 'package:flutter/material.dart';
import 'package:flutter_firebase_crud/helpers/crudoperations.dart';

class ListofNotes extends StatefulWidget {
  @override
  _ListofNotesState createState() => _ListofNotesState();
}

class _ListofNotesState extends State<ListofNotes> {
  CrudOperations crudOperations = CrudOperations.getInstance();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: FutureBuilder(
          future: crudOperations.readAllNotes(),
          builder: (BuildContext ctx, AsyncSnapshot snapShot) {
            if (snapShot.hasError) {
              return Text('NO Data to Load , Error in Fetching ');
            }
            if (!snapShot.hasData) {
              return Center(child: CircularProgressIndicator());
            }
            if (snapShot.hasData) {
              print("Data is ${snapShot.data[0].data()}");
            }
            return ListView.builder(
              itemCount: snapShot.data.length,
              itemBuilder: (BuildContext c, int index) {
                return ListTile(
                  title: Text(snapShot.data[index].data()["name"]),
                  subtitle: Text(snapShot.data[index].data()["desc"]),
                  leading: Text(snapShot.data[index].data()["author"]),
                );
              },
            );
          },
        ),
      ),
    );
  }
}
